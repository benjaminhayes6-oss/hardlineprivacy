var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var search_google_exports = {};
__export(search_google_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(search_google_exports);
async function handler(event) {
  try {
    const { GOOGLE_API_KEY, GOOGLE_CX, ALLOWED_ORIGINS } = process.env;
    if (!GOOGLE_API_KEY || !GOOGLE_CX) return json(500, { error: "Google keys not configured" });
    const p = new URLSearchParams(event.queryStringParameters || {});
    const q = (p.get("q") || "").trim();
    const start = p.get("start") || "1";
    if (!q) return json(400, { error: "Missing q" });
    const u = new URL("https://www.googleapis.com/customsearch/v1");
    u.searchParams.set("key", GOOGLE_API_KEY);
    u.searchParams.set("cx", GOOGLE_CX);
    u.searchParams.set("q", q);
    u.searchParams.set("start", start);
    const r = await fetch(u.toString());
    const d = await r.json();
    const items = (d.items || []).map((it) => ({ title: it.title, url: it.link, snippet: it.snippet, source: "google" }));
    return json(200, { q, engine: "google", items }, { origins: ALLOWED_ORIGINS, ttl: 60 });
  } catch (e) {
    return json(500, { error: "Google search error", details: e.message });
  }
}
function json(s, b, o = {}) {
  const h = base(o.origins, o.ttl);
  return { statusCode: s, headers: h, body: JSON.stringify(b) };
}
function base(origins, ttl) {
  const allow = (origins || "").split(",").map((s) => s.trim()).filter(Boolean);
  const h = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": `public, max-age=${ttl || 0}` };
  if (allow.length) {
    h["Access-Control-Allow-Origin"] = allow[0];
    h["Vary"] = "Origin";
  }
  return h;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
