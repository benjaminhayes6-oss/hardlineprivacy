var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var entitlements_me_exports = {};
__export(entitlements_me_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(entitlements_me_exports);
var import_blobs = require("@netlify/blobs");
var import_jwt = require("./_lib/jwt.js");
function json(status, body) {
  return { statusCode: status, headers: { "Content-Type": "application/json; charset=utf-8" }, body: JSON.stringify(body) };
}
async function handler(event) {
  try {
    const cookies = event.headers.cookie || "";
    const token = (cookies.match(/hp_session=([^;]+)/) || [])[1] || "";
    const payload = (0, import_jwt.verifyJWT)(token, process.env.JWT_SECRET);
    const email = (payload.email || "").toLowerCase();
    const store = (0, import_blobs.getStore)("entitlements");
    const rec = await store.get(email);
    const isAdmin = (process.env.HP_ADMIN_EMAILS || "").split(",").map((s) => s.trim().toLowerCase()).includes(email);
    const entitled = isAdmin || !!rec && JSON.parse(rec).entitled;
    return json(200, { entitled, email, admin: isAdmin });
  } catch (e) {
    return json(200, { entitled: false });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
