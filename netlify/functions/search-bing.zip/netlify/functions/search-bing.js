var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var search_bing_exports = {};
__export(search_bing_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(search_bing_exports);
async function handler(event) {
  try {
    const { BING_V7_KEY, ALLOWED_ORIGINS } = process.env;
    if (!BING_V7_KEY) return json(500, { error: "Bing key not configured" });
    const p = new URLSearchParams(event.queryStringParameters || {});
    const q = (p.get("q") || "").trim();
    const offset = p.get("offset") || "0";
    const count = p.get("count") || "10";
    if (!q) return json(400, { error: "Missing q" });
    const u = new URL("https://api.bing.microsoft.com/v7.0/search");
    u.searchParams.set("q", q);
    u.searchParams.set("count", count);
    u.searchParams.set("offset", offset);
    u.searchParams.set("safeSearch", "Moderate");
    const r = await fetch(u.toString(), { headers: { "Ocp-Apim-Subscription-Key": BING_V7_KEY } });
    const d = await r.json();
    const web = d.webPages && d.webPages.value || [];
    const items = web.map((it) => ({ title: it.name, url: it.url, snippet: it.snippet, source: "bing" }));
    return json(200, { q, engine: "bing", items }, { origins: ALLOWED_ORIGINS, ttl: 60 });
  } catch (e) {
    return json(500, { error: "Bing search error", details: e.message });
  }
}
function json(s, b, o = {}) {
  const h = base(o.origins, o.ttl);
  return { statusCode: s, headers: h, body: JSON.stringify(b) };
}
function base(origins, ttl) {
  const allow = (origins || "").split(",").map((s) => s.trim()).filter(Boolean);
  const h = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": `public, max-age=${ttl || 0}` };
  if (allow.length) {
    h["Access-Control-Allow-Origin"] = allow[0];
    h["Vary"] = "Origin";
  }
  return h;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
