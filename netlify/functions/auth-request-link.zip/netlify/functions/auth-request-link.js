var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var auth_request_link_exports = {};
__export(auth_request_link_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(auth_request_link_exports);
var import_crypto = __toESM(require("crypto"));
var import_blobs = require("@netlify/blobs");
function json(status, body) {
  return { statusCode: status, headers: { "Content-Type": "application/json; charset=utf-8" }, body: JSON.stringify(body) };
}
async function sendEmail(to, subject, html) {
  const provider = (process.env.EMAIL_PROVIDER || "").toLowerCase();
  const apiKey = process.env.EMAIL_API_KEY || "";
  const from = process.env.EMAIL_FROM || "no-reply@hardlineprivacy.com";
  if (provider === "mailgun") {
    const domain = process.env.EMAIL_DOMAIN || "hardlineprivacy.com";
    const form = new URLSearchParams({ from, to, subject, html });
    const resp = await fetch(`https://api.mailgun.net/v3/${domain}/messages`, {
      method: "POST",
      headers: { "Authorization": "Basic " + Buffer.from("api:" + apiKey).toString("base64") },
      body: form
    });
    if (!resp.ok) throw new Error("Mailgun error: " + resp.status);
    return;
  }
  if (provider === "sendgrid") {
    const resp = await fetch("https://api.sendgrid.com/v3/mail/send", {
      method: "POST",
      headers: { "Authorization": "Bearer " + apiKey, "Content-Type": "application/json" },
      body: JSON.stringify({ personalizations: [{ to: [{ email: to }] }], from: { email: from }, subject, content: [{ type: "text/html", value: html }] })
    });
    if (!resp.ok) throw new Error("SendGrid error: " + resp.status);
    return;
  }
  if (provider === "postmark") {
    const resp = await fetch("https://api.postmarkapp.com/email", {
      method: "POST",
      headers: { "X-Postmark-Server-Token": apiKey, "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify({ From: from, To: to, Subject: subject, HtmlBody: html })
    });
    if (!resp.ok) throw new Error("Postmark error: " + resp.status);
    return;
  }
  throw new Error("Unknown EMAIL_PROVIDER: " + provider);
}
async function handler(event) {
  if (event.httpMethod !== "POST") return json(405, { error: "Method not allowed" });
  let email;
  try {
    email = (JSON.parse(event.body || "{}").email || "").trim();
  } catch {
    email = "";
  }
  if (!email) return json(400, { error: "Missing email" });
  if (!process.env.EMAIL_PROVIDER || !process.env.EMAIL_API_KEY) return json(500, { error: "Email delivery is not configured." });
  const token = import_crypto.default.randomBytes(24).toString("hex");
  const store = (0, import_blobs.getStore)("login_tokens");
  const rec = { email: email.toLowerCase(), exp: Date.now() + 15 * 60 * 1e3 };
  await store.set(token, JSON.stringify(rec));
  const base = process.env.URL || "https://hardlineprivacy.com";
  const loginUrl = `${base}/api/auth-consume-link?token=${token}`;
  try {
    await sendEmail(email, "Your Hardline Privacy sign-in link", `<p>Click below to sign in. This link expires in 15 minutes.</p><p><a href="${loginUrl}">${loginUrl}</a></p><p>If you didn't request this, you can safely ignore this email.</p>`);
  } catch (e) {
    return json(500, { error: "Failed to send sign-in email. Please try again later." });
  }
  return json(200, { ok: true });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
