var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var admin_exports = {};
__export(admin_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(admin_exports);
var import_blobs = require("@netlify/blobs");
var import_jwt = require("./_lib/jwt.js");
function json(status, body) {
  return { statusCode: status, headers: { "Content-Type": "application/json; charset=utf-8" }, body: JSON.stringify(body) };
}
function isAdminEmail(email) {
  return (process.env.HP_ADMIN_EMAILS || "").split(",").map((s) => s.trim().toLowerCase()).includes((email || "").toLowerCase());
}
async function requireAdmin(event) {
  const cookies = event.headers.cookie || "";
  const token = (cookies.match(/hp_session=([^;]+)/) || [])[1] || "";
  const payload = (0, import_jwt.verifyJWT)(token, process.env.JWT_SECRET);
  if (!isAdminEmail(payload.email)) throw new Error("not admin");
  return payload.email.toLowerCase();
}
async function handler(event) {
  try {
    await requireAdmin(event);
    const store = (0, import_blobs.getStore)("entitlements");
    const action = (event.queryStringParameters || {}).action || "list";
    if (action === "list") {
      const out = [];
      for await (const key of store.list()) {
        const val = await store.get(key);
        out.push(JSON.parse(val));
      }
      return json(200, out);
    }
    const body = JSON.parse(event.body || "{}");
    const email = (body.email || "").toLowerCase();
    if (!email) return json(400, { error: "Missing email" });
    if (action === "grant") {
      const rec = { email, entitled: true, plan: body.plan || "admin-grant", updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
      await store.set(email, JSON.stringify(rec));
      return json(200, { ok: true, rec });
    }
    if (action === "revoke") {
      const rec = { email, entitled: false, plan: null, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
      await store.set(email, JSON.stringify(rec));
      return json(200, { ok: true, rec });
    }
    return json(400, { error: "Unknown action" });
  } catch (e) {
    return json(403, { error: "Forbidden" });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
