var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var jwt_exports = {};
__export(jwt_exports, {
  signJWT: () => signJWT,
  verifyJWT: () => verifyJWT
});
module.exports = __toCommonJS(jwt_exports);
var import_crypto = __toESM(require("crypto"));
function signJWT(payload, secret, { expSeconds = 7 * 24 * 3600, kid = "k1" } = {}) {
  const header = { alg: "HS256", typ: "JWT", kid };
  const iat = Math.floor(Date.now() / 1e3);
  const exp = iat + expSeconds;
  const body = { ...payload, iat, exp };
  const b64 = (obj) => Buffer.from(JSON.stringify(obj)).toString("base64url");
  const h = b64(header);
  const p = b64(body);
  const toSign = `${h}.${p}`;
  const sig = import_crypto.default.createHmac("sha256", secret).update(toSign).digest("base64url");
  return `${toSign}.${sig}`;
}
function verifyJWT(token, secret) {
  if (!token || token.split(".").length !== 3) throw new Error("bad token");
  const [h, p, s] = token.split(".");
  const sig = import_crypto.default.createHmac("sha256", secret).update(`${h}.${p}`).digest("base64url");
  if (sig !== s) throw new Error("bad signature");
  const payload = JSON.parse(Buffer.from(p, "base64url").toString("utf8"));
  if (payload.exp && payload.exp < Math.floor(Date.now() / 1e3)) throw new Error("expired");
  return payload;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  signJWT,
  verifyJWT
});
